import { IconDefinition } from '../types';
declare const SnippetsFill: IconDefinition;
export default SnippetsFill;
