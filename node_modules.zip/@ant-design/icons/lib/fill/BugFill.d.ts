import { IconDefinition } from '../types';
declare const BugFill: IconDefinition;
export default BugFill;
