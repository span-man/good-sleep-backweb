import { IconDefinition } from '../types';
declare const HourglassFill: IconDefinition;
export default HourglassFill;
