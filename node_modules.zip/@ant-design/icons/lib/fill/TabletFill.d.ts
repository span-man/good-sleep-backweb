import { IconDefinition } from '../types';
declare const TabletFill: IconDefinition;
export default TabletFill;
