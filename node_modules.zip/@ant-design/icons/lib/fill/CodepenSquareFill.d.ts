import { IconDefinition } from '../types';
declare const CodepenSquareFill: IconDefinition;
export default CodepenSquareFill;
