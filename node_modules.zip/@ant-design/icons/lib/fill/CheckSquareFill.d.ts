import { IconDefinition } from '../types';
declare const CheckSquareFill: IconDefinition;
export default CheckSquareFill;
