import { IconDefinition } from '../types';
declare const FolderFill: IconDefinition;
export default FolderFill;
