import { IconDefinition } from '../types';
declare const EuroCircleFill: IconDefinition;
export default EuroCircleFill;
