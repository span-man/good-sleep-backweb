import { IconDefinition } from '../types';
declare const VideoCameraFill: IconDefinition;
export default VideoCameraFill;
