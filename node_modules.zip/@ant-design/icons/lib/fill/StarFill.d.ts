import { IconDefinition } from '../types';
declare const StarFill: IconDefinition;
export default StarFill;
