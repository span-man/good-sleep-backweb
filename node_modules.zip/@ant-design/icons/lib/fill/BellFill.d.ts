import { IconDefinition } from '../types';
declare const BellFill: IconDefinition;
export default BellFill;
