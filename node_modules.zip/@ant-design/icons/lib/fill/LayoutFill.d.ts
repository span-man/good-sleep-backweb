import { IconDefinition } from '../types';
declare const LayoutFill: IconDefinition;
export default LayoutFill;
