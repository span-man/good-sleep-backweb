import { IconDefinition } from '../types';
declare const SoundFill: IconDefinition;
export default SoundFill;
