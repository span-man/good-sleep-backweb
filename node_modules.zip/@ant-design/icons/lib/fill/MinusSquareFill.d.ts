import { IconDefinition } from '../types';
declare const MinusSquareFill: IconDefinition;
export default MinusSquareFill;
