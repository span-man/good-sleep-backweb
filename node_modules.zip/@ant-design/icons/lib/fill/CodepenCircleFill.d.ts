import { IconDefinition } from '../types';
declare const CodepenCircleFill: IconDefinition;
export default CodepenCircleFill;
