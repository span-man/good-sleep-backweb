import { IconDefinition } from '../types';
declare const AlertFill: IconDefinition;
export default AlertFill;
