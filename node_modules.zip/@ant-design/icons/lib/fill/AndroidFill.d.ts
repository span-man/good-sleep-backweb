import { IconDefinition } from '../types';
declare const AndroidFill: IconDefinition;
export default AndroidFill;
