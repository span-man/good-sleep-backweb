import { IconDefinition } from '../types';
declare const MessageFill: IconDefinition;
export default MessageFill;
