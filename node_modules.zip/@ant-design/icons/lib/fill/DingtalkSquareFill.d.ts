import { IconDefinition } from '../types';
declare const DingtalkSquareFill: IconDefinition;
export default DingtalkSquareFill;
