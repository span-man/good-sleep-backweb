import { IconDefinition } from '../types';
declare const HighlightFill: IconDefinition;
export default HighlightFill;
