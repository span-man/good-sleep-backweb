import { IconDefinition } from '../types';
declare const TagsFill: IconDefinition;
export default TagsFill;
