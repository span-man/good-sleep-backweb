import { IconDefinition } from '../types';
declare const CloseCircleFill: IconDefinition;
export default CloseCircleFill;
