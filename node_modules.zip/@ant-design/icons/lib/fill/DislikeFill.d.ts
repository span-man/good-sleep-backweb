import { IconDefinition } from '../types';
declare const DislikeFill: IconDefinition;
export default DislikeFill;
