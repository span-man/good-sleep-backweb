import { IconDefinition } from '../types';
declare const InboxOutline: IconDefinition;
export default InboxOutline;
