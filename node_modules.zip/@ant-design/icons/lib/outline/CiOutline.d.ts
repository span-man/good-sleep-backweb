import { IconDefinition } from '../types';
declare const CiOutline: IconDefinition;
export default CiOutline;
