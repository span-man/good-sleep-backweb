import { IconDefinition } from '../types';
declare const FlagOutline: IconDefinition;
export default FlagOutline;
