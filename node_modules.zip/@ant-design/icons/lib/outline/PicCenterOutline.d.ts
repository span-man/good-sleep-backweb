import { IconDefinition } from '../types';
declare const PicCenterOutline: IconDefinition;
export default PicCenterOutline;
