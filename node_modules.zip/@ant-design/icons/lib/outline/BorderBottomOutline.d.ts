import { IconDefinition } from '../types';
declare const BorderBottomOutline: IconDefinition;
export default BorderBottomOutline;
