import { IconDefinition } from '../types';
declare const EuroOutline: IconDefinition;
export default EuroOutline;
