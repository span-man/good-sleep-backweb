import { IconDefinition } from '../types';
declare const EyeOutline: IconDefinition;
export default EyeOutline;
