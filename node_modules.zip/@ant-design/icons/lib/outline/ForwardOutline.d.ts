import { IconDefinition } from '../types';
declare const ForwardOutline: IconDefinition;
export default ForwardOutline;
