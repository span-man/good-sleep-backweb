import { IconDefinition } from '../types';
declare const DownSquareOutline: IconDefinition;
export default DownSquareOutline;
