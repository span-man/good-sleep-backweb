import { IconDefinition } from '../types';
declare const CarOutline: IconDefinition;
export default CarOutline;
