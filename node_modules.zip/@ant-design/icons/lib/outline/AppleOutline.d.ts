import { IconDefinition } from '../types';
declare const AppleOutline: IconDefinition;
export default AppleOutline;
