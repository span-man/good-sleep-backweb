import { IconDefinition } from '../types';
declare const FastBackwardOutline: IconDefinition;
export default FastBackwardOutline;
