import { IconDefinition } from '../types';
declare const DribbbleOutline: IconDefinition;
export default DribbbleOutline;
