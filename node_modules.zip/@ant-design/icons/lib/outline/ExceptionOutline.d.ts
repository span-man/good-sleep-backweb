import { IconDefinition } from '../types';
declare const ExceptionOutline: IconDefinition;
export default ExceptionOutline;
