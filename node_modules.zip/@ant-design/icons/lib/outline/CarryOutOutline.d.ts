import { IconDefinition } from '../types';
declare const CarryOutOutline: IconDefinition;
export default CarryOutOutline;
