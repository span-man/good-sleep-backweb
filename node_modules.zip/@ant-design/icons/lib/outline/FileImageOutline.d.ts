import { IconDefinition } from '../types';
declare const FileImageOutline: IconDefinition;
export default FileImageOutline;
