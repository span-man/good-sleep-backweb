import { IconDefinition } from '../types';
declare const PicRightOutline: IconDefinition;
export default PicRightOutline;
