import { IconDefinition } from '../types';
declare const CalculatorOutline: IconDefinition;
export default CalculatorOutline;
