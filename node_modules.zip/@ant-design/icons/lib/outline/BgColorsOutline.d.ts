import { IconDefinition } from '../types';
declare const BgColorsOutline: IconDefinition;
export default BgColorsOutline;
