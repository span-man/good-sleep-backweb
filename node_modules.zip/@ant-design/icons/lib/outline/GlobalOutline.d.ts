import { IconDefinition } from '../types';
declare const GlobalOutline: IconDefinition;
export default GlobalOutline;
