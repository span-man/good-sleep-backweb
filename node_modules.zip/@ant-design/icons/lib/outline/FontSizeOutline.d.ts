import { IconDefinition } from '../types';
declare const FontSizeOutline: IconDefinition;
export default FontSizeOutline;
