import { IconDefinition } from '../types';
declare const NotificationOutline: IconDefinition;
export default NotificationOutline;
