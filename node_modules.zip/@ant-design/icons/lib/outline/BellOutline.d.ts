import { IconDefinition } from '../types';
declare const BellOutline: IconDefinition;
export default BellOutline;
