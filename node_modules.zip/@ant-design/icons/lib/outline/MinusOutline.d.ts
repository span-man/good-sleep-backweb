import { IconDefinition } from '../types';
declare const MinusOutline: IconDefinition;
export default MinusOutline;
