import { IconDefinition } from '../types';
declare const InteractionOutline: IconDefinition;
export default InteractionOutline;
