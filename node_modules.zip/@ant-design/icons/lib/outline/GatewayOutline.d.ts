import { IconDefinition } from '../types';
declare const GatewayOutline: IconDefinition;
export default GatewayOutline;
