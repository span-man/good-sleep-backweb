import { IconDefinition } from '../types';
declare const CaretLeftOutline: IconDefinition;
export default CaretLeftOutline;
