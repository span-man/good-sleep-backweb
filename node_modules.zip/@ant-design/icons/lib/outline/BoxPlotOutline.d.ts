import { IconDefinition } from '../types';
declare const BoxPlotOutline: IconDefinition;
export default BoxPlotOutline;
